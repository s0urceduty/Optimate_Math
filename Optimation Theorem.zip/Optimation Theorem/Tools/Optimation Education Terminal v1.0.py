# Optimation Education Terminal v1.0
# Sourceduty.com

'''
Optimation math refers to the process of improving a mathematical model by adjusting one or more variable weights within a given range, such as between 1 and 100.
The variables A and B are set apart from the weights of each these variables.
'''

import numpy as np

def display_menu():
    print("\n----------------------------------------")
    print(" Optimation Education Terminal v1.0 ")
    print("----------------------------------------\n")
    print("This program allows you to explore the balance and trade-offs between two competing variables, A and B.")
    print("Use the menu below to modify variables, weights, and view optimation results.\n")
    print("----------------------------------------")
    print(" Main Menu ")
    print("----------------------------------------")
    print("1. Adjust Variable A")
    print("2. Adjust Variable B")
    print("3. Adjust Weight for A")
    print("4. Adjust Weight for B")
    print("5. Optimate and Display Results")
    print("6. Help")
    print("7. Exit")
    print("----------------------------------------\n")

def display_help():
    print("\n----------------------------------------")
    print(" Help Menu ")
    print("----------------------------------------\n")
    print("Optimation refers to the process of optimizing or improving a mathematical model by adjusting one or more variables within a given range, such as between 1 and 100.")
    print("In this context, 'weighting variable A' and 'weighting variable B' mean assigning values from 1-100 that represent the relative importance or influence of each variable in relation to the other.")
    print("These weights are then applied to determine the final contribution of both variables towards the outcome of the model.")
    print("Essentially, optimation involves finding the optimal balance between two variables by adjusting their weights and observing how it affects the overall result.")
    print("A [90%> B\n")
    print("----------------------------------------\n")

def adjust_value(variable_name, current_value):
    while True:
        try:
            new_value = int(input(f"Enter new value for {variable_name}: "))
            return new_value
        except ValueError:
            print("Invalid input. Please enter a numerical value.")

def adjust_weight(variable_name, current_value):
    while True:
        try:
            new_value = int(input(f"Enter new weight for {variable_name} (1-100): "))
            if 1 <= new_value <= 100:
                return new_value
            else:
                print("Invalid input. Please enter a value between 1 and 100.")
        except ValueError:
            print("Invalid input. Please enter a numerical value.")

def optimate_system(A_value, B_value, weight_A, weight_B):
    # Normalize weights to sum to 100
    total_weight = weight_A + weight_B
    norm_weight_A = weight_A / total_weight
    norm_weight_B = weight_B / total_weight
    
    # Optimation calculation (Example: Weighted Sum)
    outcome = (A_value * norm_weight_A) + (B_value * norm_weight_B)
    
    print("\n----------------------------------------")
    print(" Optimation Results ")
    print("----------------------------------------\n")
    print(f"Variable A: {A_value}")
    print(f"Variable B: {B_value}")
    print(f"Weight for A: {weight_A}")
    print(f"Weight for B: {weight_B}")
    print(f"Normalized A Weight: {norm_weight_A:.2f}")
    print(f"Normalized B Weight: {norm_weight_B:.2f}")
    print(f"Optimation Outcome: {outcome:.2f}")
    print("----------------------------------------\n")

def main():
    A_value = 10  # Default value for A
    B_value = 20  # Default value for B
    weight_A = 50  # Default starting weight for A
    weight_B = 50  # Default starting weight for B

    while True:
        display_menu()
        choice = input("Select an option: ")

        if choice == "1":
            A_value = adjust_value("A")
        elif choice == "2":
            B_value = adjust_value("B")
        elif choice == "3":
            weight_A = adjust_weight("A", weight_A)
        elif choice == "4":
            weight_B = adjust_weight("B", weight_B)
        elif choice == "5":
            optimate_system(A_value, B_value, weight_A, weight_B)
        elif choice == "6":
            display_help()
        elif choice == "7":
            print("Exiting the program.\n")
            exit()
        else:
            print("Invalid choice. Please select a valid option.\n")

if __name__ == "__main__":
    main()