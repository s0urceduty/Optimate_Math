import sys
import random
from datetime import datetime
from PySide6.QtCore import Qt, QTimer, QTime, QDate
from PySide6.QtGui import QPainter, QColor, QFont
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLabel, QMainWindow, QHBoxLayout

class TrafficSignal:
    def __init__(self, name, offset):
        self.name = name
        self.offset = offset
        self.redLight = QColor("grey")
        self.yellowLight = QColor("grey")
        self.greenLight = QColor("grey")
        self.emergencyLight = QColor("grey")

    def setRed(self):
        self.redLight = QColor("red")
        self.yellowLight = QColor("grey")
        self.greenLight = QColor("grey")
        self.emergencyLight = QColor("grey")

    def setYellow(self):
        self.redLight = QColor("grey")
        self.yellowLight = QColor("yellow")
        self.greenLight = QColor("grey")
        self.emergencyLight = QColor("grey")

    def setGreen(self):
        self.redLight = QColor("grey")
        self.yellowLight = QColor("grey")
        self.greenLight = QColor("green")
        self.emergencyLight = QColor("grey")

    def setEmergency(self):
        self.emergencyLight = QColor("blue")

class DrawingCanvas(QWidget):
    def __init__(self, signals):
        super().__init__()
        self.signals = signals
        self.setMinimumHeight(450)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        font = QFont("Arial", 10)
        painter.setFont(font)
        painter.setPen(Qt.white)

        for direction, signal in self.signals.items():
            self.drawTrafficSignal(painter, signal, direction)

    def drawTrafficSignal(self, painter, signal, direction):
        offset = signal.offset
        label_x = offset + 5
        painter.drawText(label_x, 20, signal.name)
        painter.setBrush(QColor("black"))
        painter.drawRect(offset, 30, 100, 340)
        painter.setBrush(signal.redLight)
        painter.drawEllipse(offset + 3, 40, 94, 100)
        painter.setBrush(signal.yellowLight)
        painter.drawEllipse(offset + 3, 150, 94, 100)
        painter.setBrush(signal.greenLight)
        painter.drawEllipse(offset + 3, 260, 94, 100)
        if "Sidewalk" in direction:
            painter.setBrush(signal.emergencyLight)
            painter.drawEllipse(offset + 3, 40, 94, 100)

class StreetIntersection(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Optimated Traffic Light Simulation")
        self.setGeometry(100, 100, 940, 750)

        self.signals = {
            "North": TrafficSignal("North", 0),
            "South": TrafficSignal("South", 120),
            "East": TrafficSignal("East", 240),
            "West": TrafficSignal("West", 360),
            "NorthSidewalk": TrafficSignal("North Pedestrian", 480),
            "SouthSidewalk": TrafficSignal("South Pedestrian", 600),
            "EastSidewalk": TrafficSignal("East Pedestrian", 720),
            "WestSidewalk": TrafficSignal("West Pedestrian", 840)
        }

        self.weights = {"NorthSouth": 50, "EastWest": 50}
        self.traffic = {"North": 0, "South": 0, "East": 0, "West": 0}
        self.log = []
        self.emergency = False

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        self.timeLabel = QLabel()
        self.dateLabel = QLabel()
        self.timeLabel.setStyleSheet("color: white; font-size: 16px;")
        self.dateLabel.setStyleSheet("color: white; font-size: 12px;")
        self.timeLabel.setAlignment(Qt.AlignRight)
        self.dateLabel.setAlignment(Qt.AlignRight)

        time_layout = QVBoxLayout()
        time_layout.addWidget(self.timeLabel)
        time_layout.addWidget(self.dateLabel)

        header = QHBoxLayout()
        header.addStretch()
        header.addLayout(time_layout)
        layout.addLayout(header)

        self.canvas = DrawingCanvas(self.signals)
        layout.addWidget(self.canvas)

        self.logTextEdit = QTextEdit(self)
        self.logTextEdit.setFont(QFont("Arial", 10))
        self.logTextEdit.setReadOnly(True)
        layout.addWidget(self.logTextEdit)

        self.setStyleSheet("background-color: black; color: white;")

        self.traffic_timer = QTimer(self)
        self.traffic_timer.timeout.connect(self.timerExpire)
        self.traffic_timer.start(6000)

        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self.updateClock)
        self.clock_timer.start(1000)
        self.updateClock()
        self.updateLog()

    def updateClock(self):
        self.timeLabel.setText(QTime.currentTime().toString("hh:mm:ss AP"))
        self.dateLabel.setText(QDate.currentDate().toString("dddd, MMMM d, yyyy"))

    def timerExpire(self):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.simulateTraffic()

        if self.emergency:
            for signal in self.signals.values():
                signal.setEmergency()
            self.log.append(f"[{timestamp}] Emergency Mode: All signals set to BLUE.")
        else:
            if self.weights["NorthSouth"] >= self.weights["EastWest"]:
                self.signals["North"].setGreen()
                self.signals["South"].setGreen()
                self.signals["East"].setRed()
                self.signals["West"].setRed()
                self.signals["NorthSidewalk"].setGreen()
                self.signals["SouthSidewalk"].setGreen()
                self.signals["EastSidewalk"].setRed()
                self.signals["WestSidewalk"].setRed()
                self.log.append(
                    f"[{timestamp}] North-South GREEN | Weight: {self.weights['NorthSouth']}% "
                    f"| Traffic NS: {self.traffic['North']}N + {self.traffic['South']}S | "
                    f"EW: {self.traffic['East']}E + {self.traffic['West']}W"
                )
            else:
                self.signals["East"].setGreen()
                self.signals["West"].setGreen()
                self.signals["North"].setRed()
                self.signals["South"].setRed()
                self.signals["EastSidewalk"].setGreen()
                self.signals["WestSidewalk"].setGreen()
                self.signals["NorthSidewalk"].setRed()
                self.signals["SouthSidewalk"].setRed()
                self.log.append(
                    f"[{timestamp}] East-West GREEN | Weight: {self.weights['EastWest']}% "
                    f"| Traffic EW: {self.traffic['East']}E + {self.traffic['West']}W | "
                    f"NS: {self.traffic['North']}N + {self.traffic['South']}S"
                )

            shift = random.randint(-10, 10)
            self.weights["NorthSouth"] = max(0, min(100, self.weights["NorthSouth"] + shift))
            self.weights["EastWest"] = 100 - self.weights["NorthSouth"]

        self.updateLog()
        self.canvas.update()

    def simulateTraffic(self):
        for direction in ["North", "South", "East", "West"]:
            self.traffic[direction] = random.randint(0, 25)

    def updateLog(self):
        self.logTextEdit.setPlainText("\n".join(self.log[-10:]))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_E:
            self.emergency = not self.emergency
            status = "Activated" if self.emergency else "Deactivated"
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.log.append(f"[{timestamp}] Emergency {status}")
            self.updateLog()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = StreetIntersection()
    window.show()
    sys.exit(app.exec())
